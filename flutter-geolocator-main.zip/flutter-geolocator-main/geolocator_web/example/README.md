# geolocator_example

Demonstrates how to directly use the geolocator_web package in a Flutter web application.

## Getting Started

To run the example App take the following steps:

1. Change into the `geolocator_web/example` directory (assuming the current directory is the root of the repository execute `cd geolocator_web/example`);
2. Run `flutter pub get` to download all required dependencies;
3. Finally run `flutter run -d chrome` to run the example App in the Chrome browser.
