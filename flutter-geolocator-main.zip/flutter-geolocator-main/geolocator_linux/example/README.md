# geolocator_linux_example

Demonstrates how to use the geolocator_linux plugin.
