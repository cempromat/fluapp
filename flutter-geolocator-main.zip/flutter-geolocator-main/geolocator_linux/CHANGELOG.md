## 0.1.2

- Migrates to Dart SDK 2.15.0 and Flutter 2.8.0.

## 0.1.1

- Fixes repository URL of the package.

## 0.1.0

- Initial implementation for Linux.
